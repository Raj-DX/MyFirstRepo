sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    return Controller.extend("dxc.fin.ar.rajvansh01.controller.BaseController",{

    });
});